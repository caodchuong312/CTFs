Treasure Hunt
============

**Category**: web

**Difficulty**: Easy

**Author**: Crem#2193

_Well the world has been looking for this treasure for the last 25 years. Maybe you will have a better chance at finding it?_